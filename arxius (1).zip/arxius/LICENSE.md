# Licencia Creative Commons Reconocimiento - No Comercial - Compartir Igual 3.0 España (CC BY-NC-SA 3.0)

Este trabajo está licenciado bajo la [Licencia Creative Commons Reconocimiento - No Comercial - Compartir Igual 3.0 España (CC BY-NC-SA 3.0)](https://creativecommons.org/licenses/by-nc-sa/3.0/es/).

---

## Resumen

Esta licencia permite que otros compartan, copien y distribuyan tu trabajo, así como adaptarlo o transformarlo, siempre que:  

- Reconozcan la autoría original.  
- No utilicen el trabajo con fines comerciales.  
- Distribuyan las obras derivadas bajo la misma licencia.  

---

## Texto legal completo

Puedes consultar el texto completo de la licencia aquí:  
https://creativecommons.org/licenses/by-nc-sa/3.0/es/legalcode

---

## Atribución y condiciones

Se debe dar crédito adecuado, proporcionar un enlace a esta licencia e indicar si se han realizado cambios. Cualquier obra derivada debe distribuirse con la misma licencia y no se pueden imponer restricciones adicionales.

---

© 2025 Mireia Consarnau
