---
layout: default
title: "Unidad 1. Fundamentos de la Inteligencia Artificial y el Aprendizaje Automático"
---

## Lección 1. ¿Qué es la IA? De la mente humana a las máquinas inteligentes

- [Material teórico (PDF)](https://github.com/mireiaconsarnau/machine_learning/raw/main/unidad1/l1.pdf)
- [Vídeo de recapitulación de conceptos clave (YOUTUBE)](https://youtu.be/p27AhdHxi_o)

